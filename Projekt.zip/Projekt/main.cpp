#include <stdio.h>
#include <math.h>
#include "winbgi2.h"

const int mx = 1;
const int my = 1;
int fix[2 * (mx + 1)*(my + 1)];

#include "MesLib.h"

int main()
{
	int n = 2 * (mx + 1)*(my + 1); // globalna liczba stopni swobody
	double *d = new_vector(n); // Zaalokuj wektor przemieszczen wezlowych
	double *F = new_vector(n); // Zaalokuj wektor sil wezlowych
	double **S = new_matrix(n,n);

	// Przypisz zerowe sily wezlowe i zerowe przemieszczenia wezlow
	for (int i = 0; i < n; ++i)
	{
		F[i] = 0;
		d[i] = 0;
	}

	// Okresl, ktore stopnie swobody sa zamurowane
	fix[0] = 1;
	fix[1] = 1;
	fix[4] = 1;
	fix[5] = 1;

	// Obciazenie
	F[3] = -0.01;
	
	// Narysuj uklad
	graphics(700, 700);
	scale(0, 0.5*(my - mx - 3), mx + 3, 0.5*(my + mx + 3));
	title("X", "Y", "MES");
	draw(d, F);
	wait();

	// Zwolnij pamiec
	free_vector(d);
	free_vector(F);
	free_matrix(S);
	
	// Zakoncz
	return 0;
}